//
//  GTScanModel.h
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/19.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GTScanModel : NSObject
@property(nonatomic,copy)NSString *meeting_id;
@property(nonatomic,copy)NSString *person_id;
@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSString *telephone;
@end

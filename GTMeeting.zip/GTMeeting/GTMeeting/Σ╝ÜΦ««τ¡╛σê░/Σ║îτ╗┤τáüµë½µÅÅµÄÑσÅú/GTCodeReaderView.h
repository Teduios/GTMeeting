//
//  GTCodeReaderView.h
//  二维码原生扫描
//
//  Created by 王勇 on 15/11/12.
//  Copyright © 2015年 王勇. All rights reserved.
//

#import <UIKit/UIKit.h>
@protocol GTCodeReaderViewDelegate <NSObject>
- (void)readerScanResult:(NSString *)result;
@end
@interface GTCodeReaderView : UIView
@property (nonatomic,assign) id<GTCodeReaderViewDelegate>delegate;
@property (nonatomic,strong) UIImageView *readLineView;
@property (nonatomic,assign) BOOL is_Anmotion;
@property (nonatomic,assign) BOOL is_AnmotionFinished;
//开关闭扫描
- (void)start;
- (void)stop;
//初始化扫描
- (void)loopDrawLine;
@end

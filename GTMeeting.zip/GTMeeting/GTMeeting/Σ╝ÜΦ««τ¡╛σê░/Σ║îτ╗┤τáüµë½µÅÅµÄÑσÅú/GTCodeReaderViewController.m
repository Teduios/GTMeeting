//
//  GTCodeReaderViewController.m
//  二维码原生扫描
//
//  Created by 王勇 on 15/11/12.
//  Copyright © 2015年 王勇. All rights reserved.
//

#import "GTCodeReaderViewController.h"
#import "GTCodeReaderView.h"
#import "AFNetworking.h"
#import <AVFoundation/AVFoundation.h>
#import <AudioToolbox/AudioToolbox.h>
#import "GTScanModel.h"
#import "MBProgressHUD.h"
#import "GTAlertViewController.h"
#import "GTPerMeetingViewController.h"
#import "UIViewController+GTAlertView.h"
#import "GTSeconeViewController.h"

#define DeviceMaxHeight ([UIScreen mainScreen].bounds.size.height)
#define DeviceMaxWidth ([UIScreen mainScreen].bounds.size.width)
#define widthRate DeviceWidth/320
#define IOS8 ([[UIDevice currentDevice].systemVersion intValue] >= 8 ? YES : NO)
//用来设定扫描读取信息后停顿的时间
#define reScanQRCord 10

@interface GTCodeReaderViewController () <GTCodeReaderViewDelegate,AVCaptureMetadataOutputObjectsDelegate,UIImagePickerControllerDelegate,UIAlertViewDelegate,UINavigationControllerDelegate>
//二维码扫描对象
@property (nonatomic,strong) GTCodeReaderView *readView;
@property (nonatomic,assign) BOOL isFirst;
@property (nonatomic,assign) BOOL isPush;
//脸部扫描
@property (nonatomic,strong) CIDetector *detector;
@property (nonatomic,strong) NSString *result;
@property(nonatomic,copy)NSString *person_id;
@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSString *telephone;
@end

@implementation GTCodeReaderViewController

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.title = @"会议扫描";
    self.view.backgroundColor = [UIColor whiteColor];
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc] initWithTitle:@"返回" style:UIBarButtonItemStyleDone target:self action:@selector(back)];
    self.navigationItem.leftBarButtonItem = leftItem;
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc] initWithTitle:@"相册" style:UIBarButtonItemStyleDone target:self action:@selector(alumb)];
    self.navigationItem.rightBarButtonItem = rightItem;
    self.isFirst = YES;
    self.isPush = NO;
     //开始扫描
    [self initScan];
    
}

#pragma mark - 初始化扫描
- (void)initScan
{
    //扫描页面的View视图
    if (self.readView)
    {
        [self.readView removeFromSuperview];
        self.readView = nil;
    }
    self.readView = [[GTCodeReaderView alloc] initWithFrame:CGRectMake(0, 0, DeviceMaxWidth, DeviceMaxHeight)];
    self.readView.backgroundColor = [UIColor clearColor];
    //扫描线动画
    self.readView.is_AnmotionFinished = YES;
    self.readView.alpha = 0;
    //设置扫描View页面的代理为本身
    self.readView.delegate = self;
    [self.view addSubview:self.readView];
    [UIView animateWithDuration:0.5 animations:^{
        self.readView.alpha = 1;
    } completion:nil];
    
}
#pragma mark - 返回
- (void)back
{
    [self.navigationController popViewControllerAnimated:YES];
}
#pragma mark - 相册
- (void)alumb
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = @"正在加载...";
    hud.dimBackground = YES;
    
    //选取验证二维码类型，key值高精度
    //Detector检测器，检测二维码类型，Accuracy检测经度：最高经度
    self.detector = [CIDetector detectorOfType:CIDetectorTypeQRCode context:nil options:@{CIDetectorAccuracy : CIDetectorAccuracyHigh}];
    //是否支持相册功能
    if (![UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypePhotoLibrary])
    {
        //判断是否支持iOS8
        if (IOS8)
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"未开启访问相机功能,现在去开启!" delegate:self cancelButtonTitle:@"取消" otherButtonTitles:@"确定", nil];
            alert.tag = 4;
            [alert show];
        } else {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"设备不支持访问相册，请在设置->隐私->照片中进行设置！" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alert show];
        }
        return;
    }
    self.isPush = YES;
    UIImagePickerController *mediaUI = [[UIImagePickerController alloc] init];
    //相册类型为相册库
    mediaUI.sourceType =  UIImagePickerControllerSourceTypePhotoLibrary;

    mediaUI.mediaTypes = [UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypeSavedPhotosAlbum];
    mediaUI.allowsEditing = NO;
    mediaUI.delegate = self;
    //进入相册
    [self presentViewController:mediaUI animated:YES completion:nil];
    
    [hud hide:YES afterDelay:0];
}
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    //选择编辑的图片
    UIImage *image = [info objectForKey:UIImagePickerControllerEditedImage];
    if (!image)
    {
        //选择原生的图片
        image = [info objectForKey:UIImagePickerControllerOriginalImage];
    }
    //扫描线动画
    self.readView.is_Anmotion = YES;

    NSArray *features = [self.detector featuresInImage:[CIImage imageWithCGImage:image.CGImage]];
    if (features.count >= 1)
    {
        [picker dismissViewControllerAnimated:YES completion:nil];

        CIQRCodeFeature *feature = [features objectAtIndex:0];
        NSString *scannerResult = feature.messageString;
        //播放扫描二维码的声音
        SystemSoundID SoundID;
        NSString *strFilePath = [[NSBundle mainBundle] pathForResource:@"noticeMusic" ofType:@"wav"];
        AudioServicesCreateSystemSoundID((__bridge CFURLRef _Nonnull)([NSURL fileURLWithPath:strFilePath]), &SoundID);
        AudioServicesPlaySystemSound(SoundID);
        [self accordingQRcode:scannerResult];
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:nil message:@"该图像没有包含一个二维码" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
        [alert show];
        [picker dismissViewControllerAnimated:YES completion:nil];
        self.readView.is_Anmotion = NO;
        [self.readView start];
    }

}
#pragma mark - 点击相册右上方取消
- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [picker dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - GTCodeReaderViewDelegate
- (void)readerScanResult:(NSString *)result
{
    //停止扫描
    self.readView.is_Anmotion = YES;//!
    [self.readView stop];
    //播放声音
    SystemSoundID SoundID;
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"noticeMusic" ofType:@"wav"];
    AudioServicesCreateSystemSoundID((__bridge CFURLRef _Nonnull)([NSURL fileURLWithPath:filePath]), &SoundID);
    AudioServicesPlaySystemSound(SoundID);
    [self accordingQRcode:result];
    [self performSelector:@selector(reScanStart) withObject:nil afterDelay:reScanQRCord];
}
#pragma mark - 解析二维码
- (void)accordingQRcode:(NSString *)result
{
    UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"扫描结果" message:result delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
    self.result = result;
    NSLog(@"!!!!!self.result:%@",self.result);
    GTMeetingModel *model =self.willMutableArray[0];
    NSLog(@"!!!!!model.meeting_id:%@",model.meeting_id);

    
    
    alert.delegate = self;
    alert.tag = 10;
    [alert show];
}

#pragma mark - 重新开启扫描
- (void)reScanStart
{
    self.readView.is_Anmotion = NO;

    if(self.readView.is_AnmotionFinished)
    {
        [self.readView loopDrawLine];
    }
    
    [self.readView start];
}


#pragma mark - alertViewDelegate
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (alertView.tag == 10)
    {
        if (buttonIndex == 0)
        {
            //获取本地数据库保存的用户信息
            NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
            self.person_id = [userDefaults valueForKey:@"person_id"];
            self.telephone =[userDefaults valueForKey:@"telephone"];

            //扫描后点击弹出框按钮将用户信息传到后台
            NSString *url = [NSString stringWithFormat:@"http://115.159.62.43/Ydhy1234/query_MeetingSign.action?meetingid=%@&personid=%@&telephone=%@",self.result,self.person_id,self.telephone];
           
            NSLog(@"人员ID：%@",self.person_id);
            AFHTTPRequestOperationManager *manager = [AFHTTPRequestOperationManager manager];
            manager.requestSerializer = [AFJSONRequestSerializer serializer];
            manager.responseSerializer = [AFJSONResponseSerializer serializer];
            //发送请求
            [manager GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
                
                NSLog(@"成功");
                
                    //判断是will还是end页面调转而来
                    //扫描成功，点击弹出框按钮后进入到当前会议的详情页
                     //为了扫描后返回当前会议的详情页
                    for (int i=0; i<self.willMutableArray.count; i++)
                    {
                        //遍历所有待开会议
                        GTMeetingModel *model =self.willMutableArray[i];
                        //如果遍历到的会议ID和当前扫描的会议ID一致的话就跳到当前会议的详情页
                        if ([model.meeting_id isEqualToString:self.result])
                        {
                            GTSeconeViewController *secVc = [GTSeconeViewController new];
                            secVc.meetingModel = model;

                            UINavigationController *nvi = [[UINavigationController alloc]initWithRootViewController:secVc];
                            //进入下一页
                            [self presentViewController:nvi animated:YES completion:nil];
                        }
                        else
                        {
                            
                            GTAlertViewController *alertVC = [GTAlertViewController new];
                            UINavigationController *nvi = [[UINavigationController alloc]initWithRootViewController:alertVC];
                            //进入下一页
                            [self presentViewController:nvi animated:YES completion:nil];
    
                        }
                    }

              
            } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                NSLog(@"失败：%@",error);
            }];
            
        }
    }
}


- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    if (self.isFirst || self.isPush)
    {
        if (self.readView)
        {
            [self reScanStart];
        }
    }
}
- (void)viewDidDisappear:(BOOL)animated
{
    [super viewDidDisappear:animated];
    if (self.readView)
    {
        //停止扫描
        self.readView.is_Anmotion = YES;
    }
}
- (void)viewDidAppear:(BOOL)animated
{
    [super viewDidAppear:animated];
    if (self.isFirst)
    {
        self.isFirst = NO;
    }
    if (self.isPush)
    {
        self.isPush = NO;
    }
}
@end

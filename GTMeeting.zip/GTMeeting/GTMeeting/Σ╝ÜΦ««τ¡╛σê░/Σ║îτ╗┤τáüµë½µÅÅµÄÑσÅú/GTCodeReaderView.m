//
//  GTCodeReaderView.m
//  二维码原生扫描
//
//  Created by 王勇 on 15/11/12.
//  Copyright © 2015年 王勇. All rights reserved.
//

#import "GTCodeReaderView.h"
#import <AVFoundation/AVFoundation.h>

#define DeviceMaxHeight ([UIScreen mainScreen].bounds.size.height)
#define DeviceMaxWidth  ([UIScreen mainScreen].bounds.size.width)
#define widthRate DeviceMaxWidth/320
#define contentTitleStr @"666666"//正文颜色较深
@interface GTCodeReaderView () <AVCaptureMetadataOutputObjectsDelegate>
@property (nonatomic,strong) AVCaptureSession *session;
@end

@implementation GTCodeReaderView
- (instancetype)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame])
    {
        [self instanceDevice];
    }
    return self;
}

// 配置View
- (void)instanceDevice
{
    //扫描区域
    CGRect imageViewRect = CGRectMake(60*widthRate, (DeviceMaxHeight-200*widthRate)/2, 200*widthRate, 200*widthRate);
    UIImageView *scanZoomBack = [[UIImageView alloc] initWithFrame:imageViewRect];
    scanZoomBack.backgroundColor = [UIColor clearColor];
    scanZoomBack.layer.borderColor = [UIColor whiteColor].CGColor;
    scanZoomBack.layer.borderWidth = 2.5;
    scanZoomBack.image = [UIImage imageNamed:@"scanscanBg"];
    //配置扫描线
    CGRect scanCrop = [self getScanCrop:imageViewRect readerViewFram:self.frame];
    [self addSubview:scanZoomBack];
    //获取摄像设备
    AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
    //创建输入流
    AVCaptureDeviceInput *input = [AVCaptureDeviceInput deviceInputWithDevice:device error:nil];
    //创建输出流
    AVCaptureMetadataOutput *output = [[AVCaptureMetadataOutput alloc] init];
    //设置代理 在主线程刷新
    [output setMetadataObjectsDelegate:self queue:dispatch_get_main_queue()];
    output.rectOfInterest = scanCrop;
    //初始化链接对象
    self.session = [[AVCaptureSession alloc] init];
    //高质量采集率
    [self.session setSessionPreset:AVCaptureSessionPresetHigh];
    if (input)
    {
        [self.session addInput:input];
    }
    if (output)
    {
        [self.session addOutput:output];
        //设置二维码扫描编码格式（条形码和二维码兼容）
        NSMutableArray *typeArray = [NSMutableArray array];
        //二维码
        if ([output.availableMetadataObjectTypes containsObject:AVMetadataObjectTypeQRCode])
        {
            [typeArray addObject:AVMetadataObjectTypeQRCode];
        }
        if ([output.availableMetadataObjectTypes containsObject:AVMetadataObjectTypeEAN8Code])
        {
            [typeArray addObject:AVMetadataObjectTypeEAN8Code];
        }
        if ([output.availableMetadataObjectTypes containsObject:AVMetadataObjectTypeEAN13Code])
        {
            [typeArray addObject:AVMetadataObjectTypeEAN13Code];
        }
        if ([output.availableMetadataObjectTypes containsObject:AVMetadataObjectTypeCode128Code])
        {
            [typeArray addObject:AVMetadataObjectTypeCode128Code];
        }
        
        output.metadataObjectTypes = typeArray;
    }
    //设置预览图层（让用户看到扫描情况）
    AVCaptureVideoPreviewLayer *layer = [AVCaptureVideoPreviewLayer layerWithSession:self.session];
    //设置图层的属性
    layer.videoGravity = AVLayerVideoGravityResizeAspectFill;
    //设置图层的大小
    layer.frame = self.layer.bounds;
    //将图层添加到视图图层
    [self.layer insertSublayer:layer atIndex:0];
    [self setOverlayPickView:self];
    //开始捕捉
    [self.session startRunning];
}
- (CGRect)getScanCrop:(CGRect)imageViewRect readerViewFram:(CGRect)readerViewFram
{
    CGFloat x,y,width,height;
    x = (CGRectGetHeight(readerViewFram) - CGRectGetHeight(imageViewRect))/2/CGRectGetHeight(readerViewFram);
    y = (CGRectGetWidth(readerViewFram) - CGRectGetWidth(imageViewRect))/2/CGRectGetWidth(readerViewFram);
    width = CGRectGetHeight(readerViewFram)/CGRectGetHeight(imageViewRect);
    height = CGRectGetWidth(readerViewFram)/CGRectGetWidth(imageViewRect);
    return CGRectMake(x, y, width, height);
}
#pragma mark - 分割配置视图
- (void)setOverlayPickView:(GTCodeReaderView *)readerView
{
    CGFloat wid = 60*widthRate;
    CGFloat hei = (DeviceMaxHeight-200*widthRate)/2;;
    CGFloat alpha = 0.6;
    
    //最上层view
    UIView *upView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, DeviceMaxWidth, hei)];
    upView.alpha = alpha;
    upView.backgroundColor = [self colorFromHex:contentTitleStr];
    [self addSubview:upView];
    
    //用于说明的label
    UILabel *explainLabel = [[UILabel alloc] initWithFrame:CGRectMake(0, 64+(hei-64-50*widthRate)/2, DeviceMaxWidth, 50*widthRate)];
    explainLabel.text = @"扫描签到";
    explainLabel.textAlignment = NSTextAlignmentCenter;
    explainLabel.textColor = [UIColor whiteColor];
    explainLabel.backgroundColor = [UIColor clearColor];
    [self addSubview:explainLabel];
    
    //左视图view
    UIView *leftView = [[UIView alloc] initWithFrame:CGRectMake(0, hei, wid, 200*widthRate)];
    leftView.backgroundColor = [self colorFromHex:contentTitleStr];
    leftView.alpha = alpha;
    [self addSubview:leftView];
    
    //右视图view
    UIView *rightView = [[UIView alloc] initWithFrame:CGRectMake(DeviceMaxWidth-wid, hei, wid, 200*widthRate)];
    rightView.backgroundColor = [self colorFromHex:contentTitleStr];
    rightView.alpha = alpha;
    [self addSubview:rightView];
    
    //底部视图
    UIView *downView = [[UIView alloc] initWithFrame:CGRectMake(0, hei+200*widthRate, DeviceMaxWidth, DeviceMaxHeight-hei-200*widthRate)];
    downView.alpha = alpha;
    downView.backgroundColor = [self colorFromHex:contentTitleStr];
    [self addSubview:downView];
    //开关灯button
    UIButton *lightButton = [UIButton buttonWithType:UIButtonTypeCustom];
    [lightButton setBackgroundImage:[UIImage imageNamed:@"lightSelect"] forState:UIControlStateNormal];
    [lightButton setBackgroundImage:[UIImage imageNamed:@"lightNormal"] forState:UIControlStateSelected];
    lightButton.backgroundColor = [UIColor clearColor];
    [lightButton addTarget:self action:@selector(turnButtonEvent:) forControlEvents:UIControlEventTouchUpInside];
    lightButton.frame = CGRectMake((DeviceMaxWidth-50*widthRate)/2, (CGRectGetHeight(downView.frame)-50*widthRate)/2, 50*widthRate, 50*widthRate);
    [downView addSubview:lightButton];
}
#pragma mark - 灯光开关
- (void)turnButtonEvent:(UIButton *)button
{
    button.selected = !button.selected;
    if (button.selected)
    {
        [self turnLightOn:YES];
    }
    else
    {
        [self turnLightOn:NO];
    }
}
- (void)turnLightOn:(BOOL)on
{
    Class captureDeviceClass = NSClassFromString(@"AVCaptureDevice");
    if (captureDeviceClass != nil)
    {
        AVCaptureDevice *device = [AVCaptureDevice defaultDeviceWithMediaType:AVMediaTypeVideo];
        if ([device hasTorch] && [device hasFlash])
        {
            [device lockForConfiguration:nil];
            if (on)
            {
                [device setTorchMode:AVCaptureTorchModeOn];//手电筒
                [device setFlashMode:AVCaptureFlashModeOn]; //闪光灯
            }
            else
            {
                [device setFlashMode:AVCaptureFlashModeOff];
                [device setTorchMode:AVCaptureTorchModeOff];
            }
            
            [device unlockForConfiguration];
        }
    }
    
}
#pragma mark -  色值转换16进制转成RGB
- (UIColor *)colorFromHex:(NSString *)colorStr
{
    UIColor *result = nil;
    unsigned int colorCode = 0;
    unsigned char redByte, greenByte, blueByte;
    if (colorStr != nil)
    {
        //扫描
        NSScanner *scanner = [NSScanner scannerWithString:colorStr];
        (void) [scanner scanHexInt:&colorCode];
    }
    redByte = (unsigned) (colorCode >> 16);
    greenByte = (unsigned) (colorCode >> 8);
    blueByte = (unsigned) (colorCode);
    result = [UIColor colorWithRed:(float)redByte / 0xff
                               green:(float)greenByte / 0xff
                               blue:(float)blueByte / 0xff
                               alpha:1.0];

    return result;
}
- (void)start
{
    [self.session startRunning];
}
- (void)stop
{
    [self.session stopRunning];
}
//扫描线
- (void)loopDrawLine
{
    _is_AnmotionFinished = NO;
    CGRect rect = CGRectMake(60*widthRate, (DeviceMaxHeight-200*widthRate)/2, 200*widthRate, 2);
    if (self.readLineView)
    {
        self.readLineView.alpha = 1;
        self.readLineView.frame = rect;
    }
    else
    {
        self.readLineView = [[UIImageView alloc] initWithFrame:rect];
        self.readLineView.image = [UIImage imageNamed:@"scanLine"];
        [self addSubview:self.readLineView];
    }
    
    [UIView animateWithDuration:1.5 animations:^{
        //动画配置扫描线
        self.readLineView.frame = CGRectMake(60*widthRate, (DeviceMaxHeight-200*widthRate)/2+200*widthRate-5, 200*widthRate, 2);
    } completion:^(BOOL finished)
    {
        if (!_is_Anmotion)
        {
            [self loopDrawLine];
        }
        _is_AnmotionFinished = YES;
    }];
}
#pragma mark - 扫描结果
- (void)captureOutput:(AVCaptureOutput *)captureOutput didOutputMetadataObjects:(NSArray *)metadataObjects fromConnection:(AVCaptureConnection *)connection
{
    if (metadataObjects && metadataObjects.count > 0)
    {
        AVMetadataMachineReadableCodeObject *metadataObject = [metadataObjects objectAtIndex:0];
        //输出扫描字符串
        if (self.delegate && [self.delegate respondsToSelector:@selector(readerScanResult:)])
        {
            [self.delegate readerScanResult:metadataObject.stringValue];
        }
    }
    
}
@end

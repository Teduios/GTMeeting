//
//  GTCodeReaderViewController.h
//  二维码原生扫描
//
//  Created by 王勇 on 15/11/12.
//  Copyright © 2015年 王勇. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GTMeetingModel.h"
@interface GTCodeReaderViewController : UIViewController
@property(nonatomic,strong)GTMeetingModel *meetingModel;
//用于存储待开会议的数组
@property(nonatomic,strong)NSMutableArray *willMutableArray;
//用于存储已开会议的数组
@property(nonatomic,strong)NSMutableArray *endMutableArray;
//用于判断扫描页面是哪个页面跳转来的
@property(nonatomic,strong)NSString *will;

@end

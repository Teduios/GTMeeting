//
//  GTSetViewController.m
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/18.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import "GTSetViewController.h"
#import "MBProgressHUD.h"
#import "GTLoginViewController.h"

@interface GTSetViewController () <UITableViewDataSource,UITableViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic,strong) UIImageView *imageView;
@end

@implementation GTSetViewController

-(id)init
{
    if (self = [super init])
    {
        self.title = @"个人中心";
        self.tabBarItem.image = [UIImage imageNamed:@"list_icon_settings"];
       
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height) style:UITableViewStyleGrouped];
    [self.view addSubview:self.tableView];
    [self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLineEtched];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, WINDTH, self.view.bounds.size.height/3)];
    view.backgroundColor = [UIColor colorWithRed:130/255.0 green:130/255.0  blue:130/255.0  alpha:0.9];
    [self makeHeaderView:view];
    self.tableView.tableHeaderView = view;
    self.tableView.backgroundColor = [UIColor whiteColor];
}

- (void)makeHeaderView:(UIView *)view
{
    self.imageView = [[UIImageView alloc] initWithFrame:CGRectMake(WINDTH/2-60, 35, 120, 120)];
    self.imageView.layer.cornerRadius = 60;
    self.imageView.layer.masksToBounds = YES;
    //适配图片与imageVIew大小适配
    [self.imageView setContentScaleFactor:[[UIScreen mainScreen] scale]];
    self.imageView.contentMode = UIViewContentModeScaleAspectFill;
    self.imageView.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    self.imageView.clipsToBounds = YES;
    
    self.imageView.backgroundColor = [UIColor grayColor];
    if (!self.imageView.image)
    {
        self.imageView.image = [UIImage imageNamed:@"会员-头像默认底图"];
    }
    [view addSubview:self.imageView];
    
    UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(self.imageView.frame.origin.x, self.imageView.center.y+60+8, 150, 20)];
    UILabel *departLabel = [[UILabel alloc] initWithFrame:CGRectMake(nameLabel.frame.origin.x, nameLabel.frame.origin.y + 20, nameLabel.frame.size.width, 20)];
    [view addSubview:nameLabel];
    [view addSubview:departLabel];
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *name = [userDefaults stringForKey:@"name"];
    NSString *tel = [userDefaults stringForKey:@"telephone"];
    
    nameLabel.text = [NSString stringWithFormat:@"用户名: %@",name];
    nameLabel.textAlignment = NSTextAlignmentCenter;
    nameLabel.font = [UIFont systemFontOfSize:16];
    departLabel.text = [NSString stringWithFormat:@"电 话: %@",tel];
    departLabel.textAlignment = NSTextAlignmentCenter;
    departLabel.font = [UIFont systemFontOfSize:16];
}

#pragma mark - UITableViewDataSource/UITableViewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0)
    {
        return 3;
    }
    else
    {
        return 1;
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    if (indexPath.section == 0)
    {
        if (indexPath.row == 0)
        {
            cell.textLabel.text = @"编辑头像";
        }
        else
        {
            cell.textLabel.text = @"功能待开发";
        }
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 60, WINDTH, 1)];
        view.backgroundColor = [UIColor colorWithRed:231/255.0 green:231/255.0 blue:231/255.0 alpha:1];
        [cell.contentView addSubview:view];
    }
    else
    {
        cell.textLabel.text = @"退出当前用户";
        cell.textLabel.font = [UIFont systemFontOfSize:20];
        cell.textLabel.textAlignment = NSTextAlignmentCenter;
        cell.textLabel.textColor = [UIColor whiteColor];
        cell.backgroundColor = [UIColor redColor];
        
    }
    

    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0)
    {   //进入相册更换头像
        if (indexPath.row == 0)
        {
            MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
            hud.labelText = @"正在加载...";
            hud.dimBackground = YES;
            UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
            imagePickerController.delegate = self;
            imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            imagePickerController.mediaTypes = [UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypeSavedPhotosAlbum];
            imagePickerController.allowsEditing = NO;
            [self.navigationController presentViewController:imagePickerController animated:YES completion:nil];
            [hud hide:YES afterDelay:0];
        }
        else
        {
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:@"此功能有待开发,敬请期待" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alert show];
        }
        //去掉cell选中后的状态
        [tableView deselectRowAtIndexPath:indexPath animated:YES];
    }
    //退出当前账号
    if(indexPath.section == 1)
    {
        NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
        [userDefault removeObjectForKey:@"autoLogin"];
        [userDefault removeObjectForKey:@"person_id"];
        [userDefault removeObjectForKey:@"name"];
        [userDefault removeObjectForKey:@"telephone"];
        GTLoginViewController *loginVC = [GTLoginViewController new];
        [self presentViewController:loginVC animated:YES completion:nil];

        
    }
}
- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath {
    return 60;
}
#pragma  mark - UIImagePickerControllerDelegate 
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info {
    [self dismissViewControllerAnimated:YES completion:nil];
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    self.imageView.image = image;
}
@end

//
//  GTPerMeetingViewController.m
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/10.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import "GTPerMeetingViewController.h"
#import "UILabel+GTLabel.h"
#import "GTMeetingModel.h"
#import "AFNetworking.h"
#import "MBProgressHUD.h"
#import "GTShowViewController.h"
#import "GTAttachmentModel.h"

@interface GTPerMeetingViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UILabel *label;
@property(nonatomic,strong)UIImageView *imageView;
@property(nonatomic,strong)UIScrollView *scrollerView;
@property(nonatomic,strong)UIView *viewLoad;
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSURL *url;
//拼接后的附件地址
@property(nonatomic,copy) NSString *urlStr;

//用于添加附件
@property(nonatomic,strong)NSMutableArray *mutableArray;
@end

@implementation GTPerMeetingViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.navigationItem.title = @"会议详情";
    //背景颜色
    self.view.backgroundColor = [UIColor whiteColor];
    self.scrollerView = [[UIScrollView alloc]initWithFrame:CGRectMake(0, 0, WINDTH, self.view.bounds.size.height)];
    [self.view addSubview:self.scrollerView];
    
    [self request];
    //会议通知
    [self meetingNotification];
    
}

-(void)meetingNotification
{
    //会议标题
    UILabel *titleLabel = [[UILabel alloc]init];
    titleLabel.numberOfLines = 0;
    titleLabel.text = [self.meetingModel.meeting_theme stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    titleLabel.font = [UIFont boldSystemFontOfSize:20];
    CGRect titleRect = [titleLabel textRectForBounds:CGRectMake(20, 25, WINDTH-40,MAXFLOAT) limitedToNumberOfLines:0];
    titleLabel.frame = titleRect;
    titleLabel.textAlignment = NSTextAlignmentCenter;
    [self.scrollerView addSubview:titleLabel];
    //分割线
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(10,CGRectGetMaxY(titleLabel.frame)+5, WINDTH-20, 2)];
    view.backgroundColor = [UIColor colorWithRed:130/225.0 green:130/225.0 blue:130/225.0 alpha:0.6];
    [self.scrollerView addSubview:view];
  

    //会议内容
    UILabel *content = [[UILabel alloc]init];
    content.numberOfLines = 0;
    content.text = [self.meetingModel.meeting_content stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    content.font = [UIFont systemFontOfSize:17];
    CGRect contentRect = [content textRectForBounds:CGRectMake(20, CGRectGetMaxY(view.frame)+20, WINDTH-40,MAXFLOAT) limitedToNumberOfLines:0];
    content.frame = contentRect;
    content.textColor = [UIColor blackColor];
    [self.scrollerView addSubview:content];


    //附件标题
    UILabel *attachment = [UILabel labelWithText:@"下载并查看附件:" frame:CGRectMake(20, CGRectGetMaxY(content.frame)+10, WINDTH-40, 23) color:[UIColor blackColor] alignment:NSTextAlignmentLeft font:17];
    attachment.tag = 111;
    [self.scrollerView addSubview:attachment];
    
    
    //创建tableView展示附件
   self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, CGRectGetMaxY(attachment.frame)+20, WINDTH, 150)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self.scrollerView addSubview:self.tableView];
   
    self.scrollerView.contentSize = CGSizeMake(0, CGRectGetMaxY(self.tableView.frame)+30);
    

}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //附件的数量
    return self.mutableArray.count;

}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *indenfier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indenfier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indenfier];
    }
   
    GTAttachmentModel *model = self.mutableArray[indexPath.row];
     //获取附件的名称
    if (model.attach_filepath.length != 0)
    {
        cell.textLabel.text = [model.attach_filepath stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    }
    else
    {
        UILabel *label = (UILabel *)[self.view viewWithTag:111];
        label.alpha = 0;
        
    }
   
    cell.imageView.image = [UIImage imageNamed:@"附件-2"];
    cell.accessoryType = 1;
    //缩小图片
    cell.imageView.transform = CGAffineTransformMakeScale(0.6, 0.6);
    
    return cell;

}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
     GTAttachmentModel *model = self.mutableArray[indexPath.row];
    GTShowViewController *showVC = [GTShowViewController new];
    //因为附件地址中含有中文，需要转码
   
    self.urlStr = [NSString stringWithFormat:@"http://115.159.62.43/Ydhy1234/affixfile/%@",[model.attach_filepath stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding]];
    NSString *urlEncode = [self.urlStr stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    NSURL *url = [NSURL URLWithString:urlEncode];
    showVC.url = url;
    showVC.attach_filepath = model.attach_filepath;
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    [self.navigationController pushViewController:showVC animated:YES];
   
}
//请求获取会议的附件
-(void)request
{
    NSString* url =[NSString stringWithFormat:@"http://115.159.62.43/Ydhy1234/query_MeetingInfo.action?id=%@",self.meetingModel.meeting_id];
    NSLog(@"会议ID：%@",self.meetingModel.meeting_id);
    
    AFHTTPRequestOperationManager *manger = [AFHTTPRequestOperationManager manager];
    manger.responseSerializer.acceptableContentTypes = [[NSSet alloc]initWithObjects:@"application/json", nil];
    [manger GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //responseObject就是请求下来的数据
        
        NSArray *jsonArray = [NSArray array];
        jsonArray = responseObject[2][@"rows"];
        self.mutableArray = [NSMutableArray array];
     
        //循环解析数组里面的字典
        for (NSDictionary *dic in jsonArray)
        {
            GTAttachmentModel *model = [GTAttachmentModel new];
            model.attach_filepath = dic[@"attach_filepath"];
            [self.mutableArray addObject:model];
            NSLog(@"附件名：%@",model.attach_filepath);
        }
        
        //回到主线程刷新，否则tableView不显示
        dispatch_async(dispatch_get_main_queue(), ^{
            //刷新表格
            [self.tableView reloadData];
        });
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"失败%@",error);
    }];
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


@end

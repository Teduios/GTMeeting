//
//  GTPerMeetingViewController.h
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/10.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import <UIKit/UIKit.h>

#import "GTMeetingModel.h"

@interface GTPerMeetingViewController : UIViewController
@property(nonatomic,strong)GTMeetingModel *meetingModel;
@end

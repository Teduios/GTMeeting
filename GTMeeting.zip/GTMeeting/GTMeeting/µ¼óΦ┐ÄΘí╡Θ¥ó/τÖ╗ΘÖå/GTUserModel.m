//
//  GTUserModel.m
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/13.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import "GTUserModel.h"

@implementation GTUserModel

@end

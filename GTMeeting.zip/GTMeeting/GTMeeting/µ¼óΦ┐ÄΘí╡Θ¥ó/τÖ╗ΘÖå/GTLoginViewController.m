//
//  GTLoginViewController.m
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/10.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import "GTLoginViewController.h"
#import "GTSetViewController.h"
#import "AFNetworking.h"
#import "GTUserModel.h"
#import "GTWillViewController.h"
#import "GTEndViewController.h"

@interface GTLoginViewController ()
@property(nonatomic,strong)UITextField *nameTF;
@property(nonatomic,strong)UITextField *passWord;
@property(nonatomic,strong)NSMutableArray *mutableArray;
@property(nonatomic,strong)GTUserModel *model;
@property(nonatomic,strong)NSDictionary *dic;
@property(nonatomic,assign)BOOL isLogin;
@end

@implementation GTLoginViewController

-(UITextField *)nameTF
{
    if (!_nameTF)
    {
        _nameTF = [[UITextField alloc]init];
    }
    return _nameTF;
}
-(UITextField *)passWord
{
    if (!_passWord)
    {
        _passWord = [[UITextField alloc]init];
    }
    return _passWord;
}
-(id)init
{
    if (self = [super init]) {
        self.title = @"江苏省国土资源厅会议管理平台";
    }
    return self;
}
-(void)viewWillAppear:(BOOL)animated
{

    self.navigationController.navigationBarHidden = NO;
}
- (void)viewDidLoad {
    [super viewDidLoad];
   
    
    [self createUI];
    [self request];
    
    //点击空白处隐藏键盘
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideKeyBoard)];
    [self.view addGestureRecognizer:tap];

}
- (void)hideKeyBoard
{
    [self.view endEditing:YES];
}

-(void)createUI
{
    self.view.backgroundColor = [UIColor whiteColor];

    UIView *bigView = [[UIView alloc]initWithFrame:CGRectMake(25, 85, WINDTH-50, 225)];
    bigView.backgroundColor = [UIColor colorWithRed:76/255.0 green:76/255.0  blue:76/255.0  alpha:0.6];
    bigView.layer.cornerRadius = 5;
    bigView.layer.masksToBounds = YES;
    [self.view addSubview:bigView];
    
    UILabel *label = [[UILabel alloc]initWithFrame:CGRectMake(0, 5, bigView.bounds.size.width, 30)];
    label.text = @"用户登录";
    label.textColor = [UIColor whiteColor];
    label.textAlignment = NSTextAlignmentCenter;
    [bigView addSubview:label];
    label.font = [UIFont systemFontOfSize:20];
    
    UIView *smallView = [[UIView alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(label.frame)+5, bigView.bounds.size.width-20, 102)];
    smallView.backgroundColor = [UIColor colorWithRed:130/255.0 green:130/255.0  blue:130/255.0  alpha:0.6];
    smallView.layer.masksToBounds = YES;
    smallView.layer.cornerRadius = 5;
    [bigView addSubview:smallView];
    
    //获取用户上次登陆时输入的用户名和密码
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *userName = [userDefaults valueForKey:@"name"];
    NSString *password = [userDefaults valueForKey:@"telephone"];
    
    //用户名
    UIImageView *userImage = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"未标题-2"]];
    userImage.contentMode = UIViewContentModeScaleToFill;
    userImage.frame = CGRectMake(5, 0, 50, 30);//一定要写尺寸
    if (userName)
    {
        self.nameTF.text = userName;
    }
    self.nameTF.leftView = userImage;
    self.nameTF.leftViewMode = UITextFieldViewModeAlways;
    //self.nameTF.textAlignment = NSTextAlignmentCenter;
    self.nameTF.frame = CGRectMake(10,0,smallView.bounds.size.width-20, 50);
    self.nameTF.placeholder = @"请输入您的姓名";
    [self.nameTF setValue:[UIColor colorWithRed:146/225.0 green:146/225.0 blue:146/225.0 alpha:1] forKeyPath:@"_placeholderLabel.textColor"];
    [self.nameTF setValue:[UIFont systemFontOfSize:18] forKeyPath:@"_placeholderLabel.font"];
    self.nameTF.textColor = [UIColor whiteColor];
    self.nameTF.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.nameTF.borderStyle = UITextBorderStyleNone;
    [smallView addSubview:self.nameTF];
    
    //分割线
    UIView *lineView = [[UIView alloc]initWithFrame:CGRectMake(10, CGRectGetMaxY(self.nameTF.frame), self.nameTF.bounds.size.width, 1)];
    lineView.backgroundColor = [UIColor colorWithRed:226/225.0 green:226/225.0 blue:226/225.0 alpha:1];
    [smallView addSubview:lineView];
    
    //密码
    self.passWord.frame = CGRectMake(10,CGRectGetMaxY(lineView.frame), smallView.bounds.size.width-20, 50);
    UIImageView *passwordImage = [[UIImageView alloc]initWithImage:[UIImage imageNamed:@"密码1"]];
    
    passwordImage.frame = CGRectMake(0, 0, 50, 30);
    if (password) {
        self.passWord.text = password;
    }
    self.passWord.leftView = passwordImage;
    self.passWord.leftViewMode = UITextFieldViewModeAlways;
    self.passWord.placeholder = @"请您输入密码";
    [self.passWord setValue:[UIColor colorWithRed:146/225.0 green:146/225.0 blue:146/225.0 alpha:1] forKeyPath:@"_placeholderLabel.textColor"];
    [self.passWord setValue:[UIFont systemFontOfSize:18] forKeyPath:@"_placeholderLabel.font"];
    //self.passWord.textAlignment = NSTextAlignmentCenter;
    self.passWord.clearButtonMode = UITextFieldViewModeWhileEditing;
    self.passWord.borderStyle = UITextBorderStyleNone;
    self.passWord.secureTextEntry = YES;
    [smallView addSubview:self.passWord];
    
    //登录按钮
    UIButton *loginBtn = [UIButton buttonWithType:UIButtonTypeSystem];
    loginBtn.frame = CGRectMake(45, CGRectGetMaxY(smallView.frame)+20, bigView.bounds.size.width-90, 50);
    [loginBtn setTitle:@"进入管理平台" forState:UIControlStateNormal];
    [loginBtn setTintColor:[UIColor whiteColor]];
    loginBtn.backgroundColor = [UIColor colorWithRed:130/255.0 green:130/255.0 blue:130/255.0 alpha:1];
    loginBtn.titleLabel.font = [UIFont systemFontOfSize:20];
    loginBtn.layer.cornerRadius = 5;
    loginBtn.layer.masksToBounds = YES;
    [loginBtn addTarget:self action:@selector(login) forControlEvents:UIControlEventTouchUpInside];
    [bigView addSubview:loginBtn];
    
}
//请求用户信息
-(void)request
{
    NSString *url = @"http://115.159.62.43/Ydhy1234/query_AllPersonList.action";
    AFHTTPRequestOperationManager *manger = [AFHTTPRequestOperationManager manager];
    manger.responseSerializer.acceptableContentTypes = [[NSSet alloc]initWithObjects:@"application/json", nil];
    [manger GET:url parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject){
        
        NSArray *jsonArray = [NSArray array];
        self.mutableArray = [NSMutableArray array];
        jsonArray = responseObject[0][@"rows"];
        
       
        for (NSDictionary *dic in jsonArray)
        {
            self.model = [GTUserModel new];
          
            NSString *name = dic[@"name"];
            self.model.name = [name stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
            self.model.telephone = dic[@"telephone"];
            self.model.person_id = dic[@"person_id"];
           
            [self.mutableArray addObject:self.model];
        }
        
       
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"失败%@",error);
    }];



}
-(void)login
{
    if (self.isLogin)
    {
        [self nextPage];
    }
    
    if (self.nameTF.text.length == 0 || self.passWord.text.length == 0)
    {
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:@"用户名和密码不能为空！" preferredStyle:1];
        UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
        //添加事件
        [alertController addAction:action];
        //弹出提示框
        [self presentViewController:alertController animated:YES completion:nil];
    }
    else
    {
        for (int i =0; i<self.mutableArray.count; i++)
        {
            GTUserModel *model = self.mutableArray[i];
           
            if ([self.nameTF.text isEqualToString:model.name]&&[self.passWord.text isEqualToString: model.telephone])
            {
//                //方法一：(如果是第二次直接跳过登陆此方法不可取)
//                //写个通知，把人员ID和用户名及密码传到扫描二维码页面
//                self.dic = @{@"person_id":model.person_id,@"name":model.name,@"telephone":model.telephone};
//                [[NSNotificationCenter defaultCenter]postNotificationName:@"userInfo" object:self userInfo:self.dic];
               
            //方法二：
            //把用户第一次登陆时获取的参数保存到本地数据库
                NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
                [userDefaults setObject:model.person_id forKey:@"person_id"];
                [userDefaults setObject:model.name forKey:@"name"];
                [userDefaults setObject:model.telephone forKey:@"telephone"];
                [userDefaults valueForKey:@"person_id"];
                //进入下一页
                [self nextPage];
                //记住登陆状态，下一次不需要输入密码
                NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                [defaults setBool:YES forKey:@"autoLogin"];
                self.isLogin =[defaults valueForKey:@"autoLogin"];
            
            }
            else
            {
                UIAlertController *alertController = [UIAlertController alertControllerWithTitle:@"提示" message:@"您输入的用户名或密码错误！" preferredStyle:1];
                UIAlertAction *action = [UIAlertAction actionWithTitle:@"确定" style:UIAlertActionStyleDefault handler:nil];
                //添加事件
                [alertController addAction:action];
                //弹出提示框
                [self presentViewController:alertController animated:YES completion:nil];
            }
        }
    }
   
    
}

-(void)nextPage
{

    GTWillViewController *willVC = [GTWillViewController new];
    UINavigationController *willNvi = [[UINavigationController alloc]initWithRootViewController:willVC];
    GTEndViewController *endVC = [GTEndViewController new];
    UINavigationController *endNvi = [[UINavigationController alloc]initWithRootViewController:endVC];
    GTSetViewController *setVC = [GTSetViewController new];
    UINavigationController *setNvi = [[UINavigationController alloc]initWithRootViewController:setVC];
    UITabBarController *tabBarVC = [[UITabBarController alloc]init];
    tabBarVC.viewControllers = @[willNvi,endNvi,setNvi];
    //进入下一页
    willVC.dic = self.dic;
    [self presentViewController:tabBarVC animated:YES completion:nil];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

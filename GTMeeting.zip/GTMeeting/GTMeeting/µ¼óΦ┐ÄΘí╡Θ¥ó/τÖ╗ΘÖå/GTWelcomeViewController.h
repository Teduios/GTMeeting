//
//  GTWelcomeViewController.h
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/18.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GTWelcomeViewController : UIViewController

@end

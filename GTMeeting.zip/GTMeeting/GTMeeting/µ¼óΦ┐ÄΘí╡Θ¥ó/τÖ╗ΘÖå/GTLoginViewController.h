//
//  GTLoginViewController.h
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/10.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol loginDelegate <NSObject>

-(void)passUserInfo:(NSDictionary *)dic;


@end
@interface GTLoginViewController : UIViewController


@end

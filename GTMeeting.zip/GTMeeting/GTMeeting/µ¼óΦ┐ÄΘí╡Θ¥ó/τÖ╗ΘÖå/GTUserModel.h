//
//  GTUserModel.h
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/13.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GTUserModel : NSObject
@property(nonatomic,copy)NSString *name;
@property(nonatomic,copy)NSString *telephone;
@property(nonatomic,copy)NSString *person_id;
@end

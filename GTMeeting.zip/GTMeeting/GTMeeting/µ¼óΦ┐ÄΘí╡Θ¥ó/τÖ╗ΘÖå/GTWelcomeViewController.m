//
//  GTWelcomeViewController.m
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/18.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import "GTWelcomeViewController.h"
#import "GTLoginViewController.h"
@interface GTWelcomeViewController ()

@end

@implementation GTWelcomeViewController
-(void)viewWillAppear:(BOOL)animated
{
    self.navigationController.navigationBarHidden = YES;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    UIImageView *imageView = [[UIImageView alloc]initWithFrame:self.view.bounds];
    imageView.image = [UIImage imageNamed:@"起始页背景"];
    imageView.userInteractionEnabled = YES;
    [self.view addSubview:imageView];
    
    UILabel *firstLabel = [[UILabel alloc]initWithFrame:CGRectMake(80, 130, WINDTH-160, 140)];
    firstLabel.text = @"政府会议\n管理平台";
    firstLabel.textAlignment = NSTextAlignmentCenter;
    firstLabel.numberOfLines = 0;
    [imageView addSubview:firstLabel];
    firstLabel.textColor = [UIColor whiteColor];
    firstLabel.backgroundColor = [UIColor colorWithWhite:1 alpha:0];
    firstLabel.font = [UIFont systemFontOfSize:28];
    firstLabel.layer.masksToBounds = YES;
    firstLabel.layer.borderWidth = 1.8;
    firstLabel.alpha = 0.8;
    firstLabel.layer.cornerRadius = 5;
    firstLabel.layer.borderColor = [UIColor whiteColor].CGColor;
    
    UIButton *button = [[UIButton alloc]initWithFrame:CGRectMake(65, CGRectGetMaxY(firstLabel.frame)+100, WINDTH-130, 50)];
    [button setTitle:@"进入管理平台" forState:UIControlStateNormal];
    [button setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    button.titleLabel.font = [UIFont systemFontOfSize:20];
    button.layer.masksToBounds = YES;
    button.layer.borderWidth = 0.8;
    button.backgroundColor = [UIColor colorWithWhite:1 alpha:0.25];
    button.layer.cornerRadius = 5;
    button.layer.borderColor = [UIColor whiteColor].CGColor;
    [imageView addSubview:button];
    
    [button addTarget:self action:@selector(nextPage) forControlEvents:UIControlEventTouchUpInside];


}
-(void)nextPage
{
    GTLoginViewController *loginVC = [GTLoginViewController new];
    UINavigationController *nvi = [[UINavigationController alloc]initWithRootViewController:loginVC];
    [self presentViewController:nvi animated:YES completion:nil];
    
}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

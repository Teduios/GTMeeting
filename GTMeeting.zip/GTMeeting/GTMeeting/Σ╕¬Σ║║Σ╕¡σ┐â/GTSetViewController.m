//
//  GTSetViewController.m
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/18.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import "GTSetViewController.h"
#import "MBProgressHUD.h"
#import "GTLoginViewController.h"
#import "GTMyFileViewController.h"


@interface GTSetViewController () <UITableViewDataSource,UITableViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate>
@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic,strong) UIImageView *imageView;
@property(nonatomic,strong)UITapGestureRecognizer *tap;
//@property(nonatomic,weak)UIImagePickerController *imagePickerController;
@end

@implementation GTSetViewController

-(id)init
{
    if (self = [super init])
    {
        self.title = @"个人中心";
        self.tabBarItem.image = [UIImage imageNamed:@"list_icon_settings"];
       
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height) style:UITableViewStyleGrouped];
    [self.view addSubview:self.tableView];
    //[self.tableView setSeparatorStyle:UITableViewCellSeparatorStyleSingleLineEtched];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, WINDTH, self.view.bounds.size.height/3)];
    view.backgroundColor = [UIColor colorWithRed:130/255.0 green:130/255.0  blue:130/255.0  alpha:0.3];
    [self makeHeaderView:view];
    self.tableView.tableHeaderView = view;
   
}
//tableView的头部视图
- (void)makeHeaderView:(UIView *)view
{
    self.imageView = [[UIImageView alloc] initWithFrame:CGRectMake(WINDTH/2-60, 35, 120, 120)];
    self.imageView.layer.cornerRadius = 60;
    self.imageView.layer.masksToBounds = YES;
    self.imageView.backgroundColor = [UIColor grayColor];
    //给头像加个点击事件
    self.imageView.userInteractionEnabled = YES;
    self.tap = [[UITapGestureRecognizer alloc]initWithTarget:self action:@selector(addImage)];
    [self.imageView addGestureRecognizer:self.tap];
    
    //适配图片与imageVIew大小适配
    [self.imageView setContentScaleFactor:[[UIScreen mainScreen] scale]];
    self.imageView.contentMode = UIViewContentModeScaleAspectFill;
    self.imageView.autoresizingMask = UIViewAutoresizingFlexibleHeight;
    self.imageView.clipsToBounds = YES;
    //从本地获取用户头像
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    //获取本地保存的数据
    NSData *imageData = [userDefault valueForKey:@"image"];
    //把NSdata转换成image
    UIImage *image = [UIImage imageWithData:imageData];
    
    if (image)
    {
        self.imageView.image = image;
    }
    else
    {
     self.imageView.image = [UIImage imageNamed:@"会员-头像默认底图"];
    
    }
    [view addSubview:self.imageView];
    
    UILabel *nameLabel = [[UILabel alloc] initWithFrame:CGRectMake(WINDTH/2-90, self.imageView.center.y+60+8, 180, 20)];
    UILabel *departLabel = [[UILabel alloc] initWithFrame:CGRectMake(WINDTH/2-90, nameLabel.frame.origin.y + 20, 180, 20)];
    [view addSubview:nameLabel];
    [view addSubview:departLabel];
    
    NSUserDefaults *userDefaults = [NSUserDefaults standardUserDefaults];
    NSString *name = [userDefaults stringForKey:@"name"];
    NSString *tel = [userDefaults stringForKey:@"telephone"];
    
    nameLabel.text = [NSString stringWithFormat:@"用户名: %@",name];
    nameLabel.textColor = [UIColor whiteColor];
    nameLabel.textAlignment = NSTextAlignmentCenter;
    nameLabel.font = [UIFont systemFontOfSize:16];
    departLabel.text = [NSString stringWithFormat:@"电  话: %@",tel];
    departLabel.textAlignment = NSTextAlignmentCenter;
    departLabel.textColor = [UIColor whiteColor];
    departLabel.font = [UIFont systemFontOfSize:16];
}
//添加头像
-(void)addImage
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    hud.labelText = @"正在加载...";
    hud.dimBackground = YES;
    
    UIImagePickerController *imagePickerController = [[UIImagePickerController alloc] init];
    //添加代理，才能实现进入相册点击照片的方法
    imagePickerController.delegate = self;
    imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
//    imagePickerController.mediaTypes = [UIImagePickerController availableMediaTypesForSourceType:UIImagePickerControllerSourceTypeSavedPhotosAlbum];
//    imagePickerController.allowsEditing = NO;
    [self.navigationController presentViewController:imagePickerController animated:YES completion:nil];
   
    [hud hide:YES afterDelay:0];
 
}
#pragma  mark - UIImagePickerControllerDelegate
//点击相册里面的任意图片后触发的方法
- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary<NSString *,id> *)info
{
    //获取相册里面的图片，选取的信息都在info中，info 是一个字典
    UIImage *image = [info objectForKey:UIImagePickerControllerOriginalImage];
    //将获取的图片赋给imageView
    self.imageView.image = image;
    //把获取的图片转化为NSData类型，目的是为了用NSUserDefaults保存在本地
    NSData *data = UIImagePNGRepresentation(image);
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    [userDefault setObject:data forKey:@"image"];
    
    
    [self dismissViewControllerAnimated:YES completion:nil];
}


#pragma mark - UITableViewDataSource/UITableViewDelegate
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return 2;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (section == 0)
    {
        return 3;
    }
    else
    {
        return 1;
    }
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *identifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:identifier];
    if (!cell)
    {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:identifier];
    }
    if (indexPath.section == 0)
    {
        if (indexPath.row == 0)
        {
            cell.textLabel.text = @"我的文件";
            cell.accessoryType = 1;
        }
        else
        {
            cell.textLabel.text = @"暂未开通";
        }
       
    }
    else
    {
        cell.textLabel.text = @"退出当前用户";
        cell.textLabel.font = [UIFont systemFontOfSize:20];
        cell.textLabel.textAlignment = NSTextAlignmentCenter;
        cell.textLabel.textColor = [UIColor whiteColor];
        cell.backgroundColor = [UIColor redColor];
    }

    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    //去掉cell选中后的状态
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    if (indexPath.section == 0)
    {
        
        if (indexPath.row == 0)
        {
            GTMyFileViewController *myFileVC = [GTMyFileViewController new];
            [self.navigationController pushViewController:myFileVC animated:YES];
        }
        else
        {
            //进入相册更换头像
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"温馨提示" message:@"此功能有待开发,敬请期待" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles:nil, nil];
            [alert show];
            
        }
    }
    //退出当前账号
    if(indexPath.section == 1)
    {

        GTLoginViewController *loginVC = [GTLoginViewController new];
        UINavigationController *nvi = [[UINavigationController alloc]initWithRootViewController:loginVC];
        [self presentViewController:nvi animated:YES completion:nil];

    }
}

- (CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}

@end
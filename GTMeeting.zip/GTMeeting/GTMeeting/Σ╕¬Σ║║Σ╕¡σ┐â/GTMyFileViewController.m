//
//  GTMyFileViewController.m
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/23.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import "GTMyFileViewController.h"
#import "GTShowFileViewController.h"

@interface GTMyFileViewController ()<UITableViewDataSource,UITableViewDelegate>
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSArray *fileArray;
@property(nonatomic,strong)NSURL *url;
@property(nonatomic,strong)NSMutableArray *filePathMutableArray;
@property(nonatomic,strong)NSString *filePath;

@property(nonatomic,strong)NSString *documentPath;

//用于存放过滤掉隐藏文件的文件名
@property(nonatomic,strong)NSMutableArray *fileNameMutableArr;
@end

@implementation GTMyFileViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.title = @"我的文件";
    
    
    self.tableView = [[UITableView alloc]initWithFrame:self.view.bounds style:UITableViewStylePlain];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    //tableView把没有文字的行列的分割线去掉
    [self.tableView setTableFooterView:[UIView new]];
    
    //添加编辑按钮
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc]initWithTitle:@"编辑" style:UIBarButtonItemStyleDone target:self action:@selector(edit:)];
    self.navigationItem.rightBarButtonItem = rightItem;
    
    [self getFile];
    
}
-(void)edit:(UIBarButtonItem *)sender
{
    //设定编辑模式
    [self.tableView setEditing:!self.tableView.editing animated:YES];
    //根据表格的编辑模式，改变Item题目
    sender.title = self.tableView.editing?@"确定":@"编辑";

}
//编辑模式需要代理支持（两问一答）
-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    return YES;
}
//当前行的样式是什么（删除/添加）
-(UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete|UITableViewCellEditingStyleInsert;

}
//编辑后做什么
-(void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    //1、先删沙盒里面的文件
    NSString *filePath = self.filePathMutableArray[indexPath.row];
    NSError *error = nil;
    [[NSFileManager defaultManager]removeItemAtPath:filePath error:&error];
    
    //2、先删除数组中对应的数据
    [self.filePathMutableArray removeObjectAtIndex:indexPath.row];
   
    //3、再到tableView界面删除
    [tableView deleteRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationAutomatic];
    
}
//自定义删除按钮名称
-(NSString *)tableView:(UITableView *)tableView titleForDeleteConfirmationButtonForRowAtIndexPath:(NSIndexPath *)indexPath
{

    return @"删除";
}



//从沙盒获取文件
-(void)getFile
{
    //获取docmmentPath路径
    self.documentPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];
    
    //获取NSFileManger类的单例对象
    NSFileManager *fileMgr = [NSFileManager defaultManager];
  
    //使用NSFileManger获取docmmentPath路径下所有的文件（文件名）
    self.fileArray = [fileMgr subpathsAtPath:self.documentPath];
   
    //遍历document下的所有文件，并获取文件URL路径
    self.filePathMutableArray = [NSMutableArray array];
    //用于存放去掉隐藏文件的文件名
    self.fileNameMutableArr = [NSMutableArray array];
    for (NSString *obj in self.fileArray)
    {
        if (![obj isEqualToString:@".DS_Store"])
        {
            [self.fileNameMutableArr addObject:obj];
            
            self.filePath = [self.documentPath stringByAppendingPathComponent:obj];
       
            [self.filePathMutableArray addObject:self.filePath];
            NSLog(@"路径AAA：%@",self.filePathMutableArray);
        }
    }
    
}


-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    //因为使用了编辑模式，这里一定是可变数组
    return self.filePathMutableArray.count;

}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *indentifier = @"cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:indentifier];
    if (cell == nil)
    {
        cell = [[UITableViewCell alloc]initWithStyle:UITableViewCellStyleDefault reuseIdentifier:indentifier];
    }
    cell.accessoryType = 1;
    //遍历文件数组中的所有文件
    NSString *file = self.fileNameMutableArr[indexPath.row];

    cell.textLabel.text = file;

    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
   
    NSString *filePath = self.filePathMutableArray[indexPath.row];
    
    GTShowFileViewController *showFile = [GTShowFileViewController new];
  
    showFile.urlStr = filePath;
    showFile.naviTitle = [[filePath lastPathComponent]stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];

    NSLog(@"路径：%@",filePath);
    [self.navigationController pushViewController:showFile animated:YES];

}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 55;

}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

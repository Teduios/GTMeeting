//
//  UILabel+GTLabel.m
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/10.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import "UILabel+GTLabel.h"

@implementation UILabel (GTLabel)
+(id)labelWithText:(NSString *)text frame:(CGRect )frame color:(UIColor *)color alignment:(NSTextAlignment)alignment font:(CGFloat)size
{
    UILabel *lable = [[UILabel alloc]initWithFrame:frame];
    lable.text = text;
    lable.textAlignment = alignment;
    lable.textColor = color;
    lable.font = [UIFont systemFontOfSize:size];
    return lable;
}
@end

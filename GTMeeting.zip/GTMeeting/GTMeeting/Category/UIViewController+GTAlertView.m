//
//  UIViewController+GTAlertView.m
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/26.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import "UIViewController+GTAlertView.h"

@implementation UIViewController (GTAlertView)
-(void)alertViewWithTitle:(NSString *)title message:(NSString *)message style:(NSInteger)style actionTitle:(NSString *)actionTitle target:(id)target
{
    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:style];
    UIAlertAction *action = [UIAlertAction actionWithTitle:actionTitle style:UIAlertActionStyleDefault handler:nil];
    //添加事件
    [alertController addAction:action];
    //弹出提示框
    [target presentViewController:alertController animated:YES completion:nil];
    
}


@end

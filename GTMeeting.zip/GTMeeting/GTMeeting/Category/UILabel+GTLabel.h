//
//  UILabel+GTLabel.h
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/10.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UILabel (GTLabel)
+(id)labelWithText:(NSString *)text frame:(CGRect )frame color:(UIColor *)color alignment:(NSTextAlignment)alignment font:(CGFloat)size;
@end

//
//  AppDelegate.m
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/9.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import "AppDelegate.h"
#import "GTWelcomeViewController.h"

#import "GTWillViewController.h"
#import "GTEndViewController.h"
#import "GTSetViewController.h"

@interface AppDelegate ()
@property(nonatomic,assign)BOOL isLogin;
@end

@implementation AppDelegate


- (BOOL)application:(UIApplication *)application didFinishLaunchingWithOptions:(NSDictionary *)launchOptions {
    
    _window = [[UIWindow alloc]initWithFrame:[UIScreen mainScreen].bounds];
    _window.backgroundColor = [UIColor whiteColor];
    [_window makeKeyAndVisible];
    UINavigationController *nvi = [[UINavigationController alloc]initWithRootViewController:[GTWelcomeViewController new]];
    _window.rootViewController = nvi;
   
    //从本地数据库获取@"autoLogin"的值，如果为真则自动登陆
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    self.isLogin = [defaults valueForKey:@"autoLogin"];

    if (self.isLogin)
    {
        GTWillViewController *willVC = [GTWillViewController new];
        UINavigationController *willNvi = [[UINavigationController alloc]initWithRootViewController:willVC];
        GTEndViewController *endVC = [GTEndViewController new];
        UINavigationController *endNvi = [[UINavigationController alloc]initWithRootViewController:endVC];
        GTSetViewController *setVC = [GTSetViewController new];
        UINavigationController *setNvi = [[UINavigationController alloc]initWithRootViewController:setVC];
        UITabBarController *tabBarVC = [[UITabBarController alloc]init];
        tabBarVC.viewControllers = @[willNvi,endNvi,setNvi];
        _window.rootViewController = tabBarVC;

    }
    else
    {
        UINavigationController *nvi = [[UINavigationController alloc]initWithRootViewController:[GTWelcomeViewController new]];
        _window.rootViewController = nvi;

    }
    
    //tabbar被选中时的背景图
    [[UITabBar appearance]setSelectionIndicatorImage:[UIImage imageNamed:@"底部"]];
    //被选中时图标和文字颜色
    [[UITabBar appearance]setTintColor:[UIColor whiteColor]];
    //tabbar文字往上提
    [[UITabBarItem appearance]setTitlePositionAdjustment:UIOffsetMake(0, -2)];
    //修改导航条字体颜色(返回箭头和文字)
    [[UINavigationBar appearance] setTintColor:[UIColor whiteColor]];
    //设置导航栏背景颜色
    [[UINavigationBar appearance]setBarTintColor:[UIColor redColor]];
    //设置导航标题颜色
    [[UINavigationBar appearance]setTitleTextAttributes:@{NSForegroundColorAttributeName:[UIColor whiteColor],NSFontAttributeName:[UIFont systemFontOfSize:18]}];
    
    return YES;
}




- (void)applicationWillResignActive:(UIApplication *)application {
    // Sent when the application is about to move from active to inactive state. This can occur for certain types of temporary interruptions (such as an incoming phone call or SMS message) or when the user quits the application and it begins the transition to the background state.
    // Use this method to pause ongoing tasks, disable timers, and throttle down OpenGL ES frame rates. Games should use this method to pause the game.
}

- (void)applicationDidEnterBackground:(UIApplication *)application {
    // Use this method to release shared resources, save user data, invalidate timers, and store enough application state information to restore your application to its current state in case it is terminated later.
    // If your application supports background execution, this method is called instead of applicationWillTerminate: when the user quits.
}

- (void)applicationWillEnterForeground:(UIApplication *)application {
    // Called as part of the transition from the background to the inactive state; here you can undo many of the changes made on entering the background.
}

- (void)applicationDidBecomeActive:(UIApplication *)application {
    // Restart any tasks that were paused (or not yet started) while the application was inactive. If the application was previously in the background, optionally refresh the user interface.
}

- (void)applicationWillTerminate:(UIApplication *)application {
    // Called when the application is about to terminate. Save data if appropriate. See also applicationDidEnterBackground:.
}

@end

//
//  GTShowViewController.h
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/19.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GTShowViewController : UIViewController
@property(nonatomic,strong)NSURL *url;
@property(nonatomic,copy)NSString *fileName;
@property(nonatomic,copy)NSString *attach_filepath;

@end

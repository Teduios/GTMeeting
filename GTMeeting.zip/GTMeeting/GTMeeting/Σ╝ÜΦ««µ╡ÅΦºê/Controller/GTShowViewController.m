//
//  GTShowViewController.m
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/19.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import "GTShowViewController.h"
#import "MBProgressHUD.h"
#import "AFNetworking.h"


@interface GTShowViewController ()
@property(nonatomic,strong) NSURL *urlPath;

@property(nonatomic,strong)NSString *filePaths;

@end

@implementation GTShowViewController


- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.view.backgroundColor = [UIColor whiteColor];
    
    //获取沙盒路径
    NSString *document = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)lastObject];
    //拼接本次文件存储路径-----也可以在document下面再创建一个文件夹来专门存储下载的文件
   // NSString *path = [document stringByAppendingString:@"/DownLoad"];
 
    self.filePaths = [document stringByAppendingPathComponent:self.url.lastPathComponent];
    
    //创建文件管理对象
    NSFileManager *fileMgr = [NSFileManager defaultManager];

    NSLog(@"文件所在的路径:\n%@",self.filePaths);
    if ([fileMgr fileExistsAtPath:self.filePaths])
    {
        //因为self.filePath路径中有中文必须进行转码，否则url为空!!!
        NSString *encode = [self.filePaths stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
        NSURL *url = [NSURL URLWithString:encode];
        
        NSLog(@"读取文件");
        [self readFile:url];
    }
    else
    {
        NSLog(@"直接下载");
         //下载逻辑
        [self downLoad];
    
    }
    
}
//下载附件
-(void)downLoad
{
    MBProgressHUD *hud = [MBProgressHUD showHUDAddedTo:self.view animated:YES];
    //显示的文字
    hud.labelText = @"正在加载...";
    
    NSURLSessionConfiguration *configuration = [NSURLSessionConfiguration defaultSessionConfiguration];
    AFURLSessionManager *manager = [[AFURLSessionManager alloc] initWithSessionConfiguration:configuration];
    NSURLRequest *request = [NSURLRequest requestWithURL:self.url];
  
    NSURLSessionDownloadTask *downloadTask = [manager downloadTaskWithRequest:request progress:nil destination:^NSURL *(NSURL *targetPath, NSURLResponse *response) {
        //默认保存在document下面
        NSURL *documentsDirectoryURL = [[NSFileManager defaultManager] URLForDirectory:NSDocumentDirectory inDomain:NSUserDomainMask appropriateForURL:nil create:NO error:nil];
        return [documentsDirectoryURL URLByAppendingPathComponent:[response suggestedFilename]];
        
//        //自己创建一个文件下载目录
//        NSString *path = [NSHomeDirectory() stringByAppendingString:@"/Documents/DownLoad"];
//        NSLog(@"111%@",path);
//        NSURL *URL = [NSURL URLWithString:path];
//        return [URL URLByAppendingPathComponent:[response suggestedFilename]];
        
    } completionHandler:^(NSURLResponse *response, NSURL *filePath, NSError *error) {
        
        NSLog(@"222%@",filePath);
        //此处已经在主线程了
        //下载完到沙盒读取并显示到界面
        [self readFile:filePath];
        //把AF中的地址转换成NSString类型
        NSString *mgrPath = [filePath absoluteString];//NSURL类型转成NSString类型
        //move到沙盒中
        [[NSFileManager defaultManager]moveItemAtPath:mgrPath toPath:self.filePaths error:nil];
        
        
        NSLog(@"File downloaded to: %@",filePath);
        [hud hide:YES afterDelay:0];
    }];
    
    [downloadTask resume];
    
}
-(void)readFile:(NSURL *)filePath
{
    
    UIWebView *webView = [[UIWebView alloc]initWithFrame:self.view.bounds];
    webView.scalesPageToFit = YES;
    [self.view addSubview:webView];
    [webView loadRequest:[NSURLRequest requestWithURL:filePath]];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

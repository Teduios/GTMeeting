//
//  GTAlertViewController.m
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/26.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import "GTAlertViewController.h"
#import "GTWillViewController.h"
#import "GTEndViewController.h"
#import "GTSetViewController.h"
@interface GTAlertViewController ()

@end

@implementation GTAlertViewController

- (void)viewDidLoad {
    [super viewDidLoad];
   
    self.view.backgroundColor = [UIColor whiteColor];
    
    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithTitle:@"返回" style:UIBarButtonItemStyleDone target:self action:@selector(back)];
    self.navigationItem.leftBarButtonItem = leftItem;
    
    UILabel *label = [[UILabel alloc]init];
    label.text = @"sorry!\n本次扫描签到的会议不是您将要参加的会议!\n可能您已错过签到时间，\n请再次核实，谢谢！";
    label.font = [UIFont fontWithName:@"迷你简雪君" size:25];
    label.numberOfLines = 0;
    //自适应label高度
    CGRect rect = [label textRectForBounds:CGRectMake(20, 150, WINDTH-40, MAXFLOAT)limitedToNumberOfLines:0];
    label.frame = rect;
    label.textAlignment = NSTextAlignmentCenter;
    label.textColor = [UIColor blackColor];
    [self.view addSubview:label];



}
-(void)back
{
    GTWillViewController *willVC = [GTWillViewController new];
    UINavigationController *willNvi = [[UINavigationController alloc]initWithRootViewController:willVC];
    GTEndViewController *endVC = [GTEndViewController new];
    UINavigationController *endNvi = [[UINavigationController alloc]initWithRootViewController:endVC];
    GTSetViewController *setVC = [GTSetViewController new];
    UINavigationController *setNvi = [[UINavigationController alloc]initWithRootViewController:setVC];
    UITabBarController *tabBarVC = [[UITabBarController alloc]init];
    tabBarVC.viewControllers = @[willNvi,endNvi,setNvi];
    //进入下一页
    [self presentViewController:tabBarVC animated:YES completion:nil];


}
- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

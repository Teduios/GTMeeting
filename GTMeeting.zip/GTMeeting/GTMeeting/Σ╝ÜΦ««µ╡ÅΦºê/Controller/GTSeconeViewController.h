//
//  GTSeconeViewController.h
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/26.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "GTMeetingModel.h"

@interface GTSeconeViewController : UIViewController
@property(nonatomic,strong)GTMeetingModel *meetingModel;
@end

//
//  GTEndViewController.m
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/18.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import "GTEndViewController.h"
#import "GTEndCell.h"
#import "GTPerMeetingViewController.h"
#import "AFNetworking.h"
#import "GTSearchController.h"
#import "GTCodeReaderViewController.h"
#import "MJRefresh.h"

@interface GTEndViewController ()<UITableViewDelegate,UITableViewDataSource>
@property(nonatomic,strong)UIView *endMeeting;
@property(nonatomic,strong)UITableView *tableView;
@property(nonatomic,strong)NSMutableArray *mutableArray;
@property(nonatomic,strong)NSString *timer1;

@end

@implementation GTEndViewController
-(id)init
{
    if (self = [super init])
    {
        self.title = @"已开会议";
        self.tabBarItem.image = [UIImage imageNamed:@"时钟-1"];
        
    }
    return self;
}
- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self createView];
    [self refresh];
    [self createBarButtonItem];

}
-(void)createBarButtonItem
{
//    UIBarButtonItem *leftItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"扫一扫-1"] style:UIBarButtonItemStyleDone target:self action:@selector(codeScan)];
//    self.navigationItem.leftBarButtonItem = leftItem;
    UIBarButtonItem *rightItem = [[UIBarButtonItem alloc]initWithImage:[UIImage imageNamed:@"放大镜"] style:UIBarButtonItemStyleDone target:self action:@selector(search)];
    self.navigationItem.rightBarButtonItem = rightItem;
}
////进入扫描页面
//-(void)codeScan
//{
//    GTCodeReaderViewController *codeVC = [GTCodeReaderViewController new];
//    
//    codeVC.endMutableArray = self.mutableArray;
//    
//    //[[NSNotificationCenter defaultCenter]postNotificationName:@"userInfo" object:self userInfo:self.dic];
//    [self.navigationController pushViewController:codeVC animated:YES];
//}

//进入搜索页面
-(void)search
{
    GTSearchController *search = [[GTSearchController alloc] init];
    
    search.array = [self.mutableArray copy];
    [self.navigationController pushViewController:search animated:YES];
}

-(void)createView
{

    self.tableView = [[UITableView alloc]initWithFrame:CGRectMake(0, 0, WINDTH, self.view.bounds.size.height)];
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    
    //设置分割线颜色
    self.tableView.separatorStyle = UITableViewCellSelectionStyleNone;
    self.tableView.separatorInset = UIEdgeInsetsMake(0,0, 0, 10);
    //注册
    UINib *nib = [UINib nibWithNibName:@"GTEndCell" bundle:nil];
    [self.tableView registerNib:nib forCellReuseIdentifier:@"endCell"];
}

//请求数据
-(void)request
{
    
    NSUserDefaults *userDefault = [NSUserDefaults standardUserDefaults];
    NSString *person_id =[userDefault valueForKey:@"person_id"];
    NSString* url =[NSString stringWithFormat:@"http://115.159.62.43/Ydhy1234/query_PersonNeedMeetingList.action?id=%@",person_id];
    
    NSString *urlEncode = [url stringByAddingPercentEncodingWithAllowedCharacters:[NSCharacterSet URLQueryAllowedCharacterSet]];
    AFHTTPRequestOperationManager *manger = [AFHTTPRequestOperationManager manager];
    manger.responseSerializer.acceptableContentTypes = [[NSSet alloc]initWithObjects:@"application/json", nil];
    [manger GET:urlEncode parameters:nil success:^(AFHTTPRequestOperation *operation, id responseObject) {
        //responseObject就是请求下来的数据
        
        NSArray *jsonArray = [NSArray array];
        jsonArray = responseObject[0][@"rows"];

        //循环解析数组里面的字典
        for (NSDictionary *dic in jsonArray)
        {
            GTMeetingModel *model = [GTMeetingModel new];
            model.meeting_theme = dic[@"meeting_theme"];
            model.meeting_starttime = dic[@"meeting_starttime"];
            model.meeting_id = dic[@"meeting_id"];
            model.meeting_content = dic[@"meeting_content"];
            model.meeting_place = dic[@"meeting_place"];
            model.meeting_note = dic[@"meeting_note"];
            model.meeting_date = dic[@"meeting_date"];
            model.jointime = dic[@"jointime"];
            
            //计算倒计时
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
            [dateFormatter setDateFormat:@"yyyy/MM/dd HH:mm"];
            NSString *nowTime = [dateFormatter stringFromDate:[NSDate new]];
            
            //开始倒计时的时间
            NSDate *date1 = [dateFormatter dateFromString:model.meeting_starttime];
            //当前时间
            NSDate *date2 = [dateFormatter dateFromString:nowTime];
            //时间间隔
            NSTimeInterval time = [date1 timeIntervalSinceDate:date2];
            
            int month = (int)time/(3600*24*30);
            int days = ((int)time-month*(3600*24*30))/(3600*24);
            int hours = (int)time%(3600*24)/3600;
            int min = (int)time%3600/60;
            //拿出年月日的字符串
            NSString *t1 = [NSString stringWithFormat:@"%i",month];
            NSString *t2 = [NSString stringWithFormat:@"%i",days];
            NSString *t3 = [NSString stringWithFormat:@"%i",hours];
            NSString *t4 = [NSString stringWithFormat:@"%i",min];
            //转换成int类型
            int t11 = [t1 intValue];
            int t22 = [t2 intValue];
            int t33 = [t3 intValue];
            int t44 = [t4 intValue];
            
            if (t11<=0&&t22<=0&&t33<=0&&t44<=0)
            {
                [self.mutableArray addObject:model];
            }
            
        }
        
        //加载完数据之后停止刷新
        [self.tableView.header endRefreshing];
        
        //回到主线程刷新，否则tableView不显示
        dispatch_async(dispatch_get_main_queue(), ^{
            //刷新表格
            [self.tableView reloadData];
        });
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        NSLog(@"失败%@",error);
    }];
    
}

-(void)refresh
{
    MJRefreshNormalHeader *header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        
        self.mutableArray = [NSMutableArray array];
     
        [self.mutableArray removeAllObjects];
        //
        [self request];
        
    }];
    self.tableView.header = header;
    [self.tableView.header beginRefreshing];
    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.mutableArray.count;
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    GTMeetingModel *model = self.mutableArray[indexPath.row];
    static NSString *indentifer = @"endCell";
    GTEndCell *cell = [tableView dequeueReusableCellWithIdentifier:indentifer];
    //自定义分割线
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 133, WINDTH, 5)];
    view.backgroundColor = [UIColor colorWithRed:231/255.0 green:231/255.0 blue:231/255.0 alpha:1];
    
    [cell.contentView addSubview:view];
    cell.titleLabel.text = [model.meeting_theme stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    cell.data.text = [model.meeting_starttime stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    cell.place.text = [model.meeting_place stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    if (model.jointime.length != 0)
    {
        cell.comeOn.text = @"已签到";
        cell.comeOn.textColor = [UIColor grayColor];
    }
   else
   {
       cell.comeOn.text = @"未签到";
       cell.comeOn.textColor = [UIColor redColor];
   }
    
    
    return cell;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 137;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    GTMeetingModel *model = self.mutableArray[indexPath.row];
    GTPerMeetingViewController *vc = [GTPerMeetingViewController new];
    vc.meetingModel = model;
    
    [self.navigationController pushViewController:vc animated:YES];

}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end

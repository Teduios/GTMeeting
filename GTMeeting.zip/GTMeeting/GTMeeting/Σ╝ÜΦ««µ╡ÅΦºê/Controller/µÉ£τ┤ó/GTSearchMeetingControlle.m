//
//  GTSearchMeetingControlle.m
//  GTMeeting
//
//  Created by 王勇 on 15/11/19.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import "GTSearchMeetingControlle.h"
#import "GTMeetingModel.h"
#import "GTWillCell.h"
#import "GTEndCell.h"
#import "GTPerMeetingViewController.h"
@interface GTSearchMeetingControlle () <UITableViewDataSource,UITableViewDelegate>
@property (nonatomic,strong) UITableView *tableView;
@property (nonatomic,strong) NSMutableArray *mutableArray;
@property (nonatomic,strong) NSMutableArray *timer;
@end

@implementation GTSearchMeetingControlle
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    self.view.backgroundColor = [UIColor whiteColor];
    self.title = @"查询结果";

}
- (void)viewDidLoad {
    
    self.tableView = [[UITableView alloc] initWithFrame:CGRectMake(0, 0, self.view.bounds.size.width, self.view.bounds.size.height)];
    self.tableView.separatorStyle = UITableViewCellSelectionStyleNone;
    self.tableView.separatorInset = UIEdgeInsetsMake(0, 0, 0, 10);
    self.tableView.delegate = self;
    self.tableView.dataSource = self;
    [self.view addSubview:self.tableView];
    
    self.mutableArray = [[NSMutableArray alloc] init];
    self.timer = [[NSMutableArray alloc] init];
    //遍历从will或endViewController里面的的数据
    for (GTMeetingModel *model in self.meetingArray)
    {
        //会议标题
        NSString *theme = [model.meeting_theme stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
        if ([theme rangeOfString:self.searchContent].location != NSNotFound)
        {
            //如果是从待开会议页面进来
            if (self.will)
            {
                NSDateFormatter *dateFormatter = [[NSDateFormatter alloc]init];
                [dateFormatter setDateFormat:@"yyyy/MM/dd HH:mm"];
                NSString *nowTime = [dateFormatter stringFromDate:[NSDate new]];
                
                //开始倒计时的时间
                NSDate *date1 = [dateFormatter dateFromString:model.meeting_starttime];
                //当前时间
                NSDate *date2 = [dateFormatter dateFromString:nowTime];
                //时间间隔
                NSTimeInterval time = [date1 timeIntervalSinceDate:date2];
                
                int month = (int)time/(3600*24*30);
                int days = ((int)time-month*(3600*24*30))/(3600*24);
                int hours = (int)time%(3600*24)/3600;
                int min = (int)time%3600/60;
                NSString *t = [NSString stringWithFormat:@"有%i月%i天%i小时%i分钟",month,days,hours,min];
                [self.timer addObject:t];
            }
            [self.mutableArray addObject:model];
        }
    }

    UINib *nib = [UINib nibWithNibName:@"GTWillCell" bundle:nil];
    [self.tableView registerNib:nib forCellReuseIdentifier:@"willCell"];
    UINib *nib1 = [UINib nibWithNibName:@"GTEndCell" bundle:nil];
    [self.tableView registerNib:nib1 forCellReuseIdentifier:@"endCell"];
    
}

- (void)selectEndMeeting:(NSArray *)array
{
    
    for (GTMeetingModel *model in array)
    {
        if ([model.meeting_theme rangeOfString:self.searchContent].location != NSNotFound)
        {
            [self.mutableArray addObject:model];
        }
    }
}


#pragma mark - UITableViewDalegate/UITableViewDataSource
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return self.mutableArray.count;
}
- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (self.will)
    {
        GTMeetingModel *model = self.meetingArray[indexPath.row];
        static NSString *identifier = @"willCell";
        GTWillCell *willCell = [tableView dequeueReusableCellWithIdentifier:identifier];
        UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 133, WINDTH, 5)];
        view.backgroundColor = [UIColor colorWithRed:231/255.0 green:231/255.0 blue:231/255.0 alpha:1];
        [willCell.contentView addSubview:view];
        
        willCell.titleLabel.text = [model.meeting_theme stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        willCell.data.text = [model.meeting_starttime stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        willCell.meetingTimer.text = [self.timer[indexPath.row] stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        return willCell;
    }
   
    //已开会议
    GTMeetingModel *model1 = self.mutableArray[indexPath.row];
    static NSString *identifier1 = @"endCell";
    GTEndCell *endCell = [tableView dequeueReusableCellWithIdentifier:identifier1];
    UIView *view = [[UIView alloc]initWithFrame:CGRectMake(0, 133,WINDTH, 5)];
    view.backgroundColor = [UIColor colorWithRed:231/255.0 green:231/255.0 blue:231/255.0 alpha:1];
    [endCell.contentView addSubview:view];
    endCell.titleLabel.text = [model1.meeting_theme stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    endCell.data.text = [model1.meeting_starttime stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    if (model1.jointime.length != 0)
    {
        endCell.comeOn.text = @"已经签到";
    }
    else
    {
        endCell.comeOn.text = @"未签到";
        endCell.comeOn.textColor = [UIColor redColor];
    }
    

    return endCell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    GTMeetingModel *model = self.mutableArray[indexPath.row];
    GTPerMeetingViewController *vc = [GTPerMeetingViewController new];
    vc.meetingModel = model;
    [self.navigationController pushViewController:vc animated:YES];
}
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 135;
}

@end

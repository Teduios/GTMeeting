//
//  GTSearchController.h
//  GTMeeting
//
//  Created by 王勇 on 15/11/19.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GTSearchController : UIViewController
@property (nonatomic,strong) NSArray *array;
@property (nonatomic,strong) NSString *will;
@end

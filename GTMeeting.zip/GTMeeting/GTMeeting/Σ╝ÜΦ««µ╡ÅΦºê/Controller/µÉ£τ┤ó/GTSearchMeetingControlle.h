//
//  GTSearchMeetingControlle.h
//  GTMeeting
//
//  Created by 王勇 on 15/11/19.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GTSearchMeetingControlle : UIViewController
@property (nonatomic,strong) NSString *searchContent;
@property (nonatomic,strong) NSArray *meetingArray;
@property (nonatomic,strong) NSString *will;
@end

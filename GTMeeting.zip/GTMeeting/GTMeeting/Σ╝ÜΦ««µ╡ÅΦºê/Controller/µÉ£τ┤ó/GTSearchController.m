//
//  GTSearchController.m
//  GTMeeting
//
//  Created by 王勇 on 15/11/19.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import "GTSearchController.h"
#import "GTSearchMeetingControlle.h"
@interface GTSearchController ()
@property (nonatomic,strong) UISearchBar *search;

@end

@implementation GTSearchController
- (id)init {
    if (self = [super init])
    {
        self.view.backgroundColor = [UIColor whiteColor];
        self.title = @"搜索";
    }
    return self;
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    //判断是从哪个页面跳转到搜索页面的
    if (self.will)
    {
        self.search.placeholder = @"查询待开会议";
    }
    else
    {
        self.search.placeholder = @"查询已开会议";
    }
}

- (void)viewDidLoad {
    //创建搜索栏
    self.search = [[UISearchBar alloc] initWithFrame:CGRectMake(0, 65, self.view.bounds.size.width, 50)];
    [self.view addSubview:self.search];
    
    UIBarButtonItem *searchBar = [[UIBarButtonItem alloc] initWithTitle:@"查询" style:UIBarButtonItemStyleDone target:self action:@selector(searchMeeting)];
    self.navigationItem.rightBarButtonItem = searchBar;
    //隐藏键盘的点击手势
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(hideKeyBoard)];
    [self.view addGestureRecognizer:tap];
}
- (void)hideKeyBoard
{
    [self.view endEditing:YES];
}

//点击查询会议
- (void)searchMeeting {
    
    GTSearchMeetingControlle *searchMeeting = [[GTSearchMeetingControlle alloc] init];
    searchMeeting.meetingArray = [self.array copy];
    searchMeeting.searchContent = self.search.text;
    searchMeeting.will = [self.will copy];
    [self.navigationController pushViewController:searchMeeting animated:YES];
}


@end

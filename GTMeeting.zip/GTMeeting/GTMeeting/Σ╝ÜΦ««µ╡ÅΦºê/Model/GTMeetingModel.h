//
//  GTMeetingModel.h
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/12.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GTMeetingModel : NSObject
@property(nonatomic,copy)NSString *meeting_starttime;
@property(nonatomic,copy)NSString *meeting_endtime;
@property(nonatomic,copy)NSString *meeting_place;
@property(nonatomic,copy)NSString *meeting_theme;
@property(nonatomic,copy)NSString *meeting_content;
@property(nonatomic,copy)NSString *meeting_note;
@property(nonatomic,copy)NSString *meeting_date;
@property(nonatomic,copy)NSString *meeting_applydate;
@property(nonatomic,copy)NSString *meeting_id;
@property(nonatomic,copy)NSString *jointime;


@end

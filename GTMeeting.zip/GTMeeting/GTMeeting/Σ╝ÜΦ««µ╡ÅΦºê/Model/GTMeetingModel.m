//
//  GTMeetingModel.m
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/12.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import "GTMeetingModel.h"

@implementation GTMeetingModel


@end

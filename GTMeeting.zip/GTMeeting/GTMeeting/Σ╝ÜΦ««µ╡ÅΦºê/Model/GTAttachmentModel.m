//
//  GTAttachmentModel.m
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/24.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import "GTAttachmentModel.h"

@implementation GTAttachmentModel

@end

//
//  GTAttachmentModel.h
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/24.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface GTAttachmentModel : NSObject
//附件名
@property(nonatomic,copy)NSString *attach_filepath;
@end

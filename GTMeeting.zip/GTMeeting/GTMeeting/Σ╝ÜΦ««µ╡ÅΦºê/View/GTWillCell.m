//
//  GTWillCell.m
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/11.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import "GTWillCell.h"

@implementation GTWillCell

- (void)awakeFromNib {
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end

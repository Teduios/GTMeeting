//
//  GTEndCell.h
//  GTMeeting
//
//  Created by zhuchenglong on 15/11/11.
//  Copyright © 2015年 zhuchenglong. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface GTEndCell : UITableViewCell
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *data;
@property (weak, nonatomic) IBOutlet UILabel *place;
@property (weak, nonatomic) IBOutlet UILabel *comeOn;


@end
